﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShpMerger
{
 
        public enum ShapeFileOpenMode
        {//读取要合并第一个文件
            FileReadFirst = 0,
            FileRead = 1
        }
   
}
